#ifndef ADT_H
#define ADT_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// Definition of the Bigint structure
typedef struct {
    int* digits;     // Array of digits (least significant digit first)
    int size;        // Number of digits
    bool isNegative; // Sign of the number
} Bigint;

// Function prototypes
Bigint createBigint(const char* number);
void freeBigint(Bigint* num);
Bigint addAbs(const Bigint* a, const Bigint* b);
void trim(Bigint* num);
Bigint subtractAbs(const Bigint* a, const Bigint* b);
Bigint addBigint(const Bigint* a, const Bigint* b);
Bigint subtractBigint(const Bigint* a, const Bigint* b);
void printBigint(const Bigint* num);
bool isEqualBigint(const Bigint* a, const Bigint* b);

// New function to count pairs of Bigint

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // ADT_H
