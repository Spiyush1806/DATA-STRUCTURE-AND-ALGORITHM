#include "ADT.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>



Bigint createBigint(const char* number) {
    Bigint result;
    int len = strlen(number);
    result.isNegative = (number[0] == '-');
    result.size = result.isNegative ? len - 1 : len;
    result.digits = (int*)malloc(result.size * sizeof(int));

    if (result.digits == NULL) {
        result.size = 0;
        return result;
    }

    for (int i = 0; i < result.size; i++) {
        result.digits[i] = number[len - 1 - i] - '0';
    }
    return result;
}

void freeBigint(Bigint* num) {
    if (num->digits != NULL) {
        free(num->digits);
        num->digits = NULL;
    }
    num->size = 0;
}

void trim(Bigint* num) {
    while (num->size > 1 && num->digits[num->size - 1] == 0) {
        num->size--;
    }
}

Bigint subtractAbs(const Bigint* a, const Bigint* b) {
    if (a->size < b->size || (a->size == b->size && memcmp(a->digits, b->digits, a->size * sizeof(int)) < 0)) {
        Bigint result = subtractAbs(b, a);
        result.isNegative = true;
        return result;
    }

    Bigint result;
    result.digits = (int*)malloc(a->size * sizeof(int));

    if (result.digits == NULL) {
        result.size = 0;
        return result;
    }

    result.size = 0;
    result.isNegative = false;

    int carry = 0;
    for (int i = 0; i < a->size; i++) {
        int diff = a->digits[i] - carry;
        if (i < b->size) diff -= b->digits[i];
        if (diff < 0) {
            diff += 10;
            carry = 1;
        } else {
            carry = 0;
        }
        result.digits[result.size++] = diff;
    }

    trim(&result);
    return result;
}

bool isEqualBigint(const Bigint* a, const Bigint* b) {
    if (a->isNegative != b->isNegative) {
        return false;
    }
    if (a->size != b->size) {
        return false;
    }

    for (int i = 0; i < a->size; i++) {
        if (a->digits[i] != b->digits[i]) {
            return false;
        }
    }
    return true;
}

int count_pairs(Bigint* data, int n, Bigint* target) {
    int result = 0;
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            Bigint diff = subtractAbs(&data[i], &data[j]);
            if (isEqualBigint(&diff, target)) {
                result++;
            }
            freeBigint(&diff);
        }
    }
    return result;
}

int count_pairs_from_file(const char* filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        return -1; // Error opening file
    }

    char targetStr[1000];
    fscanf(file, "%s", targetStr);

    int n;
    fscanf(file, "%d", &n);

    Bigint* data = (Bigint*)malloc(n * sizeof(Bigint));
    for (int i = 0; i < n; i++) {
        char number[1000];
        fscanf(file, "%s", number);
        data[i] = createBigint(number);
    }

    Bigint target_bigint = createBigint(targetStr);

    int result = count_pairs(data, n, &target_bigint);

    for (int i = 0; i < n; i++) {
        freeBigint(&data[i]);
    }
    freeBigint(&target_bigint);
    free(data);

    fclose(file);
    return result;
}

int main() {
    const char* filename = "test3.txt";
    int result1 = count_pairs_from_file(filename);
    printf("Number of pairs: %d\n", result1);

    // Example usage:
    Bigint data[] = {
        createBigint("5"),
        createBigint("4"),
        createBigint("3"),
        createBigint("2"),
        createBigint("1")
    };
    int n = sizeof(data) / sizeof(data[0]);
    Bigint target = createBigint("1");

    int result = count_pairs(data, n, &target); // Changed to int
    printf("Number of pairs: %d\n", result);

    // Free the allocated memory
    for (int i = 0; i < n; i++) {
        freeBigint(&data[i]);
    }
    freeBigint(&target);

    return 0;
}

