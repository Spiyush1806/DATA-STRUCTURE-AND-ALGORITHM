import ctypes

# Load the shared library
lib = ctypes.CDLL('./main.so')

def read_file(filename: str) -> tuple[list[int], int]:
    with open(filename) as file:
        # First line is the target
        target = int(file.readline())
        # Second line is the number of integers
        n = int(file.readline())
        # Read the n integers and return them as a list
        return ([int(file.readline()) for _ in range(n)], target)

# Define the structure equivalent to Bigint in Python
    
count_pairs_from_file = lib.count_pairs_from_file
count_pairs_from_file.argtypes = [ctypes.c_char_p]
count_pairs_from_file.restype = ctypes.c_int

def count_pairs_file(filename: str) -> int:
    result = count_pairs_from_file(filename.encode('ASCII'))
    return result

